AUTHOR='@xer0dayz'
VULN_NAME='Interesting Title Found'
FILENAME="$LOOT_DIR/web/title-htt*-$TARGET.txt"
MATCH='admin|dev|portal'
SEVERITY='P5 - INFO'
GREP_OPTIONS='-i'
SEARCH='positive'
SECONDARY_COMMANDS=''